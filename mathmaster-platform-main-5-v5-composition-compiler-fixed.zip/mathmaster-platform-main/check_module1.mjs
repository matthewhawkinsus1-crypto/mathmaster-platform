import fs from 'node:fs';
import path from 'node:path';
import { validateQuestionsSemantics } from './src/platform/contract/semanticValidation.js';
import { validateToolQuestion } from './src/tools/toolSchemas.js';

const dir='module1';
for (const name of fs.readdirSync(dir).filter(n=>n.endsWith('_UI_CHECKED.json')).sort()) {
  const raw=JSON.parse(fs.readFileSync(path.join(dir,name),'utf8'));
  const questions=raw.activities.flatMap(a=>(a.questions||[]).map(q=>({...q,activityRole:q.activityRole||a.role})));
  const sem=validateQuestionsSemantics(questions);
  let toolErrors=[]; let toolWarnings=[];
  questions.forEach((q,i)=>{
    const r=validateToolQuestion(q);
    if(!r.isValid) toolErrors.push(...r.errors.map(e=>`Q${i+1}: ${e}`));
    if(r.warnings?.length) toolWarnings.push(...r.warnings.map(e=>`Q${i+1}: ${e}`));
  });
  console.log('\n'+name, 'questions=',questions.length,'semantic',sem.errors.length,'errors',sem.warnings.length,'warnings','tool',toolErrors.length,'errors',toolWarnings.length,'warnings');
  for(const e of sem.errors) console.log('  SEM ERROR',e);
  for(const w of sem.warnings) console.log('  SEM WARN',w);
  for(const e of toolErrors) console.log('  TOOL ERROR',e);
}
