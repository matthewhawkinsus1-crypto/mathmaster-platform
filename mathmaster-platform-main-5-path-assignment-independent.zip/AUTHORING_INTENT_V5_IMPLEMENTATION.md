# MathMaster Authoring Intent V5 — Implemented

## Purpose

Outside AIs describe mathematical intent. MathMaster compiles that intent into the existing V4 runtime/tool contracts. V4 remains the persistence and student-runtime compatibility format.

## Pipeline

1. Parse/repair incoming AI text.
2. If `schemaVersion: 5`, compile Authoring Intent V5 to canonical V4.
3. Normalize renderer/storage aliases and question-level standards.
4. Run structural/tool validation.
5. Run semantic/student-experience validation.
6. Open teacher Preflight.

## Main implementation

- `src/platform/contract/authoringIntentV5.js`
  - stable `studentActions` vocabulary;
  - intent-to-tool resolution;
  - function/relation/sequence/graph normalization;
  - connected `relationshipModel` workflow compilation;
  - specialist workspace mappings;
  - 34 currently student-authorable runtime destinations.
- `src/assignmentBlueprint.js`
  - detects V5 and compiles it before normal V4 validation/storage.
- `src/platform/contract/authoringContract.js`
  - default teacher-facing AI contract is now V5 and is intentionally much smaller than the internal V4 developer contract.
- `scripts/validate-authoring-v5.mjs`
  - smoke validation for the compiler/contract.
- `scripts/validate-assignments.mjs`
  - batch assignment structural + semantic + registry-tool validation.

## Backward compatibility

- Existing V4 JSON still imports normally.
- Bundle V3 activity packaging still imports normally.
- A V5 bundle may contain an already-canonical typed question as an expert escape hatch; MathMaster preserves it.
- No existing assignment migration is required for V5 authoring because V5 is compiled before runtime persistence.

## Design rule

The AI should be responsible for the mathematics, source fidelity, question wording, correct answers, and student actions. MathMaster should be responsible for choosing/configuring its renderer, normalizing storage shapes, default graph windows, and rejecting a student experience that cannot actually collect the requested work.
