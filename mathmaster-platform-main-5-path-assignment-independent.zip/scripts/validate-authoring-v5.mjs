import { buildAuthoringContract } from '../src/platform/contract/authoringContract.js';
import { parseAssignmentBlueprintText, validateAssignmentQuestions } from '../src/assignmentBlueprint.js';

const sample = {
  schemaVersion: 5,
  assignment: { title: 'Authoring Intent V5 validation', courseId: 'algebra1', assignmentType: 'notesClasswork' },
  questions: [{
    standard: 'A.3C', prompt: 'Graph f(x) = 2x + 1.', studentActions: ['constructGraph'],
    function: { family: 'linear', m: 2, b: 1 },
  }],
};
const parsed = parseAssignmentBlueprintText(JSON.stringify(sample));
validateAssignmentQuestions(parsed.questions);
const contract = buildAuthoringContract({ courseId: 'algebra1' });
if (!contract.includes('Authoring Intent V5')) throw new Error('Teacher-facing contract is not V5.');
console.log(`Authoring Intent V5: PASS (${parsed.questions.length} sample question, ${parsed.repairs.length} compiler notes, contract ${contract.length} chars)`);
