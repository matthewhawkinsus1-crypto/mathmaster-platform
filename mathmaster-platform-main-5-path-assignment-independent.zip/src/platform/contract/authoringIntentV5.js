const asArray = (value) => Array.isArray(value) ? value : value == null ? [] : [value];
const isObject = (value) => value && typeof value === 'object' && !Array.isArray(value);
const clean = (value) => String(value ?? '').trim();
const normalizeToken = (value) => clean(value).toLowerCase().replace(/[^a-z0-9]+/g, '');
const ACTION_ALIASES = Object.freeze({
  solve: 'solveEquation', solveequation: 'solveEquation', answernumeric: 'solveEquation',
  solvebysteps: 'solveStepByStep', solvestepbystep: 'solveStepByStep', showsteps: 'solveStepByStep',
  fractionanswer: 'fractionAnswer', simplifyfraction: 'fractionAnswer',
  choosenumberline: 'chooseNumberLine', selectnumberline: 'chooseNumberLine',
  constructnumberline: 'constructInterval', graphinequality: 'constructInterval', constructinterval: 'constructInterval',
  writeinterval: 'writeInterval', intervalnotation: 'writeInterval',
  readgraph: 'readGraph', constructgraph: 'constructGraph', graphfunction: 'constructGraph',
  investigatefunction: 'investigateFunction', analyzegraph: 'analyzeGraph',
  analyzedomain: 'analyzeDomain', statedomain: 'stateDomain', domain: 'analyzeDomain',
  analyzerange: 'analyzeRange', staterange: 'stateRange', range: 'analyzeRange',
  analyzeincreasing: 'analyzeIncreasing', increasing: 'analyzeIncreasing',
  analyzedecreasing: 'analyzeDecreasing', decreasing: 'analyzeDecreasing',
  analyzeconstant: 'analyzeConstant', constant: 'analyzeConstant',
  analyzepositive: 'analyzePositive', positive: 'analyzePositive',
  analyzenegative: 'analyzeNegative', negative: 'analyzeNegative',
  findvertex: 'findVertex', vertex: 'findVertex', findxintercepts: 'findXIntercepts', xintercepts: 'findXIntercepts',
  findyintercept: 'findYIntercept', yintercept: 'findYIntercept', findmaximum: 'findMaximum', findminimum: 'findMinimum',
  solveforvariable: 'solveLiteral', solveliteral: 'solveLiteral',
  solvesystem: 'solveSystem', graphsystem: 'graphSystem', solveinequalitysystem: 'solveInequalitySystem', rowreduce: 'rowReduce',
  completetable: 'completeTable', readtable: 'readTable',
  orderedpair: 'stateOrderedPair', stateorderedpair: 'stateOrderedPair',
  multipleanswers: 'multipleResponses', multipleresponses: 'multipleResponses',
  identifyquantities: 'identifyQuantities', identifyvariables: 'identifyQuantities', writeequation: 'writeEquation',
  classifycontinuity: 'classifyContinuity', classifyrelationship: 'classifyContinuity',
  matchgraphstostories: 'matchGraphsToStories', matchscenarios: 'matchGraphsToStories', comparegraphs: 'compareGraphs',
  writegraphstory: 'writeGraphStory', interpretpoint: 'interpretPointInContext', interpretpointincontext: 'interpretPointInContext',
  buildmapping: 'buildMapping', plotrelation: 'plotRelation', classifyfunction: 'classifyFunction', statefunctionstatus: 'classifyFunction',
  analyzesequence: 'analyzeSequence', classifysequence: 'analyzeSequence', findterm: 'findSequenceTerm',
  findsequenceterm: 'findSequenceTerm', findmissingterm: 'findMissingTerm', writerrecursive: 'writeRecursive',
  writerecursive: 'writeRecursive', writeexplicit: 'writeExplicit', comparesequences: 'compareSequences', partialsum: 'partialSum',
  connectrepresentations: 'connectRepresentations', matchrepresentation: 'connectRepresentations', findmismatch: 'findRepresentationMismatch',
  fitline: 'fitDataModel', fitmodel: 'fitDataModel', analyzedata: 'analyzeData', predictfrommodel: 'predictFromModel',
  inverse: 'findInverse', findinverse: 'findInverse', composition: 'composeFunctions', composefunctions: 'composeFunctions',
  parabolageometry: 'analyzeParabolaGeometry', focusdirectrix: 'analyzeParabolaGeometry',
  factorpolynomial: 'factorPolynomial', dividepolynomial: 'dividePolynomial', multiplypolynomials: 'multiplyPolynomials',
  solveinequality: 'solveInequality', signchart: 'solveInequality',
  complexoperations: 'complexOperations', complexplane: 'analyzeComplex',
  exponentiallog: 'exponentialLogBridge', solveexponential: 'solveExponential', solvelogarithmic: 'solveLogarithmic',
  transformfunction: 'analyzeTransformations', analyzetransformations: 'analyzeTransformations',
  graphline: 'constructLine', constructline: 'constructLine',
  interactivealgebra: 'stepAlgebra2', modelinglab: 'modelingLab',
});

const normalizeActions = (question = {}) => {
  const source = asArray(question.studentActions || question.actions || question.studentAction);
  const actions = source.map((entry) => ACTION_ALIASES[normalizeToken(entry)] || clean(entry)).filter(Boolean);
  return [...new Set(actions)];
};

const copyCommon = (source, target = {}) => {
  ['prompt','activityRole','dok','difficultyBand','calculator','assessmentContext','context','familyId','assessedConstruct'].forEach((key) => {
    if (source[key] != null) target[key] = source[key];
  });
  if (source.standard) target.standard = source.standard;
  if (source.primaryStandard) target.primaryStandard = source.primaryStandard;
  if (source.secondaryStandards) target.secondaryStandards = source.secondaryStandards;
  if (source.prerequisiteStandards) target.prerequisiteStandards = source.prerequisiteStandards;
  if (source.alignments) target.alignments = source.alignments;
  return target;
};

const answerOf = (q) => q.answer ?? q.expectedAnswer ?? q.response?.answer ?? q.answerModel?.answer;
const acceptedOf = (q) => q.acceptedAnswers ?? q.response?.acceptedAnswers ?? q.answerModel?.acceptedAnswers;

const coreFunctionSpec = (raw = {}) => {
  const f = isObject(raw) ? raw : {};
  const family = clean(f.family || f.type || 'linear');
  const type = family === 'line' ? 'linear' : family;
  if (type === 'linear') {
    const m = Number(f.m ?? f.slope ?? f.a ?? 1);
    const b = Number(f.b ?? f.intercept ?? f.k ?? 0);
    return { type: 'linear', m, b, ...(f.domain ? { domain: f.domain } : {}) };
  }
  const out = { type };
  ['a','h','k','base','p','orientation'].forEach((key) => { if (f[key] != null) out[key] = f[key]; });
  if (f.domain) out.domain = f.domain;
  return out;
};

const toolFunctionSpec = (raw = {}) => {
  const core = coreFunctionSpec(raw);
  if (core.type !== 'linear') return core;
  return { type: 'linear', a: core.m, h: 0, k: core.b, ...(core.domain ? { domain: core.domain } : {}) };
};

const staticFunctionSpec = (raw = {}) => {
  const core = coreFunctionSpec(raw);
  if (core.type === 'linear') return { type: 'line', m: core.m, b: core.b };
  return core;
};

const graphFromIntent = (q = {}) => {
  if (isObject(q.graph)) return q.graph;
  if (isObject(q.visual?.graph)) return q.visual.graph;
  if (isObject(q.function) || isObject(q.functionSpec)) {
    return { functions: [staticFunctionSpec(q.function || q.functionSpec)] };
  }
  return undefined;
};

const analysisRequestsFromActions = (actions, q = {}) => {
  if (Array.isArray(q.analysisRequests) && q.analysisRequests.length) return q.analysisRequests;
  const notation = q.notation || q.response?.notation || 'interval';
  const map = [
    ['analyzeDomain','domain'], ['stateDomain','domain'], ['analyzeRange','range'], ['stateRange','range'],
    ['analyzeIncreasing','increasing'], ['analyzeDecreasing','decreasing'], ['analyzeConstant','constant'],
    ['analyzePositive','positive'], ['analyzeNegative','negative'],
  ];
  const requests = [];
  map.forEach(([action, kind]) => { if (actions.includes(action) && !requests.some((r) => r.kind === kind)) requests.push({ id: kind, kind, notation }); });
  const points = [
    ['findVertex','vertex','vertex'], ['findXIntercepts','xIntercepts','x-intercepts'], ['findYIntercept','yIntercept','y-intercept'],
    ['findMaximum','localMaximum','maximum'], ['findMinimum','localMinimum','minimum'],
  ];
  points.forEach(([action, feature, id]) => { if (actions.includes(action)) requests.push({ id, kind: 'point', feature }); });
  return requests;
};

const fieldFromIntent = (field, index) => {
  if (!isObject(field)) return field;
  const out = { ...field };
  out.id = out.id || `part-${index + 1}`;
  out.label = out.label || out.prompt || `Part ${index + 1}`;
  if (out.accepted != null && out.acceptedAnswers == null) out.acceptedAnswers = asArray(out.accepted);
  if (out.expected != null && out.answer == null) out.answer = out.expected;
  if (Array.isArray(out.options) && !out.type) out.type = 'choice';
  if (out.kind === 'text' && !out.type) out.type = 'text';
  delete out.expected;
  delete out.accepted;
  delete out.prompt;
  delete out.kind;
  return out;
};

const normalizeGraphChoices = (choices = []) => asArray(choices).map((item, index) => {
  if (!isObject(item)) return item;
  const id = item.id || `g${index + 1}`;
  if (item.graph) return { ...item, id };
  if (item.function || item.functionSpec) return { id, label: item.label, graph: { functions: [staticFunctionSpec(item.function || item.functionSpec)] } };
  return { ...item, id };
});

const compileRelationshipModel = (q, actions) => {
  const relationship = q.relationship || q.model || {};
  const quantities = q.quantities || relationship.quantities;
  const out = copyCommon(q, {
    type: 'relationshipModel',
    scenario: q.scenario || relationship.scenario || q.context || q.prompt,
    quantities,
    correctIndependentId: q.correctIndependentId || relationship.correctIndependentId || relationship.independentId,
    correctDependentId: q.correctDependentId || relationship.correctDependentId || relationship.dependentId,
  });
  const ask = [];
  if (actions.includes('identifyQuantities')) ask.push('quantities');
  if (actions.includes('writeEquation')) ask.push('equation');
  if (actions.includes('completeTable')) ask.push('table');
  if (actions.includes('constructGraph')) ask.push('graph');
  if (actions.some((a) => ['stateDomain','analyzeDomain'].includes(a))) ask.push('domain');
  if (actions.some((a) => ['stateRange','analyzeRange'].includes(a))) ask.push('range');
  if (actions.includes('classifyContinuity')) ask.push('continuity');
  if (ask.length > 1 || actions.some((a) => ['writeEquation','completeTable','constructGraph','stateDomain','stateRange'].includes(a))) {
    out.recipe = { name: 'functionModeling', ask: ask.length ? ask : ['quantities','equation','table','graph','domain','range','continuity'] };
  }
  const answerModel = q.answerModel || relationship.answerModel || {};
  out.correctEquation = q.correctEquation || answerModel.equation || relationship.equation || out.correctEquation;
  out.tableXValues = q.tableXValues || answerModel.tableXValues || relationship.tableXValues || out.tableXValues;
  out.graphMode = q.graphMode || answerModel.graphMode || relationship.graphMode;
  out.continuity = q.continuity || answerModel.continuity || relationship.continuity || q.relationshipType;
  out.correctDomain = q.correctDomain || answerModel.domain || relationship.domain;
  out.correctRange = q.correctRange || answerModel.range || relationship.range;
  out.notation = q.notation || answerModel.notation;
  out.graph = q.graph || relationship.graph;
  if (q.relationshipType) out.relationshipType = q.relationshipType;
  if (q.requireRelationshipType != null) out.requireRelationshipType = q.requireRelationshipType;
  Object.keys(out).forEach((key) => out[key] === undefined && delete out[key]);
  return out;
};

const resolveIntentType = (q, actions) => {
  const hint = clean(q.toolHint || q.destination || q.intentType || q.questionType);
  if (hint) return hint;
  if (q.labDefinition || actions.includes('modelingLab')) return 'modelingLab';
  if (q.data || q.points && actions.some((a) => ['analyzeData','fitDataModel','predictFromModel'].includes(a))) return 'dataModelingLab';
  if (q.inverse || q.composition || actions.some((a) => ['findInverse','composeFunctions'].includes(a))) return 'inverseCompositionLab';
  if (q.parabola || actions.includes('analyzeParabolaGeometry')) return 'parabolaGeometryLab';
  if (q.polynomial || actions.some((a) => ['factorPolynomial','dividePolynomial','multiplyPolynomials'].includes(a))) return 'polynomialWorkshop';
  if (q.signChart || actions.includes('solveInequality')) return 'signSolutionAnalyzer';
  if (q.complex || q.z || actions.some((a) => ['complexOperations','analyzeComplex'].includes(a))) return 'complexPlaneLab';
  if (q.logarithm || q.exponentialLog || actions.some((a) => ['exponentialLogBridge','solveExponential','solveLogarithmic'].includes(a))) return 'exponentialLogBridge';
  if (q.transformation || actions.includes('analyzeTransformations')) return 'transformationsLab';
  if (q.representations || q.sets || actions.some((a) => ['connectRepresentations','findRepresentationMismatch'].includes(a))) return 'representationMatch';
  if (q.sequence || actions.some((a) => ['analyzeSequence','findSequenceTerm','findMissingTerm','writeRecursive','writeExplicit','compareSequences','partialSum'].includes(a))) return 'sequenceExplorer';
  if (q.relation || q.pairs || actions.some((a) => ['buildMapping','plotRelation','classifyFunction'].includes(a))) return 'relationMapping';
  if (actions.includes('matchGraphsToStories') || (q.stories && q.candidateGraphs)) return 'graphScenarioMatch';
  if (actions.includes('compareGraphs') || (q.graphs && q.comparisonFields)) return 'graphComparison';
  if (actions.includes('writeGraphStory')) return 'graphStory';
  if (actions.includes('interpretPointInContext')) return 'contextInterpretation';
  if (actions.some((a) => ['identifyQuantities','writeEquation','classifyContinuity'].includes(a)) && (q.quantities || q.relationship || q.scenario)) return 'relationshipModel';
  if (actions.includes('solveInequalitySystem') || actions.includes('graphSystem') || actions.includes('rowReduce')) return 'systemsWorkspace';
  if (actions.includes('solveSystem') || q.equations) return 'system';
  if (actions.includes('solveLiteral') || q.solveFor) return 'literal';
  if (actions.includes('solveStepByStep')) return 'stepAlgebra';
  if (actions.includes('stepAlgebra2')) return 'stepAlgebra2';
  if (actions.includes('constructLine') || q.lineIntent) return 'graphing2';
  if (actions.includes('constructInterval') || actions.includes('writeInterval') || q.intervals) return 'intervalNumberLine';
  if (actions.includes('chooseNumberLine') || q.numberLineChoices) return 'numberLine';
  if (actions.includes('constructGraph')) return 'functionGraph';
  if (actions.includes('investigateFunction')) return 'functionInvestigation2';
  if (actions.some((a) => a.startsWith('analyze') || ['findVertex','findXIntercepts','findYIntercept','findMaximum','findMinimum'].includes(a)) && (q.function || q.functionSpec)) return 'graphAnalysis';
  if (actions.includes('readGraph') && (q.graph || q.function)) return 'graphing';
  if (actions.includes('completeTable') || q.table?.answers) return 'table';
  if (actions.includes('stateOrderedPair')) return 'orderedPair';
  if (actions.includes('multipleResponses') || q.responses || q.answerFields) return 'multiAnswer';
  if (actions.includes('fractionAnswer')) return 'fraction';
  if (actions.includes('solveEquation') || q.equation) return 'algebra';
  return null;
};

const compileOne = (q, index, repairs) => {
  if (!isObject(q)) throw new Error(`V5 question ${index + 1} must be an object.`);
  // Expert/internal escape hatch: already-canonical questions remain legal in a V5 bundle.
  if (q.type || q.toolId) {
    repairs.push(`V5 question ${index + 1} already specified an internal type; preserved for compatibility`);
    return { ...q };
  }
  const actions = normalizeActions(q);
  const type = resolveIntentType(q, actions);
  if (!type) throw new Error(`V5 question ${index + 1} does not contain enough mathematical intent to choose a student tool. Add studentActions and the needed mathematical data.`);
  let out;
  switch (type) {
    case 'algebra':
      out = copyCommon(q, { type, equation: q.equation || q.expression, answer: answerOf(q) });
      break;
    case 'fraction':
      out = copyCommon(q, { type, answer: answerOf(q), generator: q.generator });
      break;
    case 'numberLine':
      out = copyCommon(q, { type, choices: q.choices || q.numberLineChoices, answer: answerOf(q), min: q.min, max: q.max, step: q.step });
      break;
    case 'intervalNumberLine': {
      const ask = [];
      if (actions.includes('constructInterval')) ask.push('graph');
      if (actions.includes('writeInterval')) ask.push('interval');
      out = copyCommon(q, { type, inequalityText: q.inequalityText || q.inequality, intervals: q.intervals, ask: q.ask || (ask.length ? ask : ['graph','interval']), min: q.min, max: q.max, step: q.step });
      break;
    }
    case 'graphing':
      out = copyCommon(q, { type, graph: graphFromIntent(q), answer: answerOf(q), responseType: q.response?.kind });
      break;
    case 'functionGraph':
      out = copyCommon(q, { type, functionSpec: coreFunctionSpec(q.function || q.functionSpec), graph: q.graph, studentChoosesX: q.studentChoosesX ?? true, showCoordinates: q.showCoordinates });
      break;
    case 'functionInvestigation2': {
      const requests = analysisRequestsFromActions(actions, q);
      const kinds = requests.filter((r) => r.kind !== 'point').map((r) => r.kind);
      const mode = q.mode || (kinds.some((k) => ['domain','range'].includes(k)) ? 'domainRange' : kinds.some((k) => ['increasing','decreasing','constant','positive','negative'].includes(k)) ? 'behavior' : requests.some((r) => r.kind === 'point') ? 'intercepts' : 'features');
      out = copyCommon(q, { type, mode, function: toolFunctionSpec(q.function || q.functionSpec), analysisRequests: requests.length ? requests : undefined });
      break;
    }
    case 'graphAnalysis':
      out = copyCommon(q, { type, functionSpec: coreFunctionSpec(q.function || q.functionSpec), graph: q.graph, analysisRequests: analysisRequestsFromActions(actions, q) });
      break;
    case 'stepAlgebra':
      out = copyCommon(q, { type, equation: q.equation, generator: q.generator, workspaceDifficulty: q.workspaceDifficulty });
      break;
    case 'literal':
      out = copyCommon(q, { type, equation: q.equation, solveFor: q.solveFor, answer: answerOf(q) });
      break;
    case 'system':
      out = copyCommon(q, { type, equations: q.equations, answer: answerOf(q), graph: q.graph, showGraph: q.showGraph });
      break;
    case 'table':
      out = copyCommon(q, { type, table: q.table, functionSpec: q.function ? coreFunctionSpec(q.function) : q.functionSpec });
      break;
    case 'orderedPair':
      out = copyCommon(q, { type, answer: answerOf(q) || q.point, graph: q.graph });
      break;
    case 'multiAnswer': {
      const fields = q.answerFields || q.responses || q.response?.fields || [];
      out = copyCommon(q, { type, answerFields: fields.map(fieldFromIntent), table: q.table, graph: q.graph, visual: q.visual, mathDisplay: q.mathDisplay });
      break;
    }
    case 'relationshipModel':
      out = compileRelationshipModel(q, actions);
      break;
    case 'graphScenarioMatch':
      out = copyCommon(q, { type, scenarios: q.scenarios || asArray(q.stories).map((story, i) => isObject(story) ? { id: story.id || `s${i + 1}`, title: story.title, description: story.description || story.text || story.prompt } : { id: `s${i + 1}`, description: story }), graphs: normalizeGraphChoices(q.graphs || q.candidateGraphs), correctMatches: q.correctMatches || q.matches });
      break;
    case 'graphComparison':
      out = copyCommon(q, { type, graphs: normalizeGraphChoices(q.graphs || q.candidateGraphs), fields: (q.fields || q.comparisonFields || q.responses || []).map(fieldFromIntent) });
      break;
    case 'graphStory':
      out = copyCommon(q, { type, graph: graphFromIntent(q), functionSpec: q.function ? coreFunctionSpec(q.function) : q.functionSpec, minimumScenarioCharacters: q.minimumScenarioCharacters, minimumExplanationCharacters: q.minimumExplanationCharacters });
      break;
    case 'contextInterpretation':
      out = copyCommon(q, { type, scenario: q.scenario || q.context, quantityChoices: q.quantityChoices || q.quantities, graph: graphFromIntent(q), point: q.point, showGraph: q.showGraph });
      break;
    case 'relationMapping': {
      const ask = q.ask || [actions.includes('buildMapping') && 'mapping', actions.includes('plotRelation') && 'plot', actions.includes('stateDomain') && 'domain', actions.includes('stateRange') && 'range', actions.includes('classifyFunction') && 'isFunction'].filter(Boolean);
      out = copyCommon(q, { type, pairs: q.pairs || q.relation, ask: ask.length ? ask : ['mapping','domain','range','isFunction'] });
      break;
    }
    case 'modelingLab':
      out = copyCommon(q, { type, labDefinition: q.labDefinition || q.lab || q.modeling });
      break;
    case 'dataModelingLab': {
      const data = q.data || {};
      out = copyCommon(q, { type, mode: q.mode || (actions.includes('fitDataModel') ? 'lineFit' : actions.includes('predictFromModel') ? 'prediction' : 'full'), points: q.points || data.points, predictionX: q.predictionX ?? data.predictionX, predictionTolerance: q.predictionTolerance ?? data.predictionTolerance });
      break;
    }
    case 'inverseCompositionLab':
      out = copyCommon(q, { type, mode: q.mode || (actions.includes('composeFunctions') ? 'composition' : 'inverse'), f: toolFunctionSpec(q.f || q.function || q.inverse?.function), g: q.g ? toolFunctionSpec(q.g) : undefined, x: q.x, inverseBranch: q.inverseBranch });
      break;
    case 'systemsWorkspace':
      out = copyCommon(q, { type, mode: q.mode || (actions.includes('solveInequalitySystem') ? 'inequalities' : actions.includes('rowReduce') ? 'matrix' : q.linearQuadratic ? 'linearQuadratic' : 'linear'), system: q.system, inequalities: q.inequalities, matrix: q.matrix, linearQuadratic: q.linearQuadratic });
      break;
    case 'parabolaGeometryLab': {
      const p = q.parabola || {};
      out = copyCommon(q, { type, mode: q.mode || (p.focus || q.focus ? 'fromGeometry' : 'features'), h: q.h ?? p.h, k: q.k ?? p.k, p: q.p ?? p.p, orientation: q.orientation || p.orientation, focus: q.focus || p.focus, directrix: q.directrix || p.directrix });
      break;
    }
    case 'polynomialWorkshop': {
      const p = q.polynomial || {};
      const mode = q.mode || (actions.includes('dividePolynomial') ? 'division' : actions.includes('multiplyPolynomials') ? 'multiplyArea' : 'factorQuadratic');
      out = copyCommon(q, { type, mode, coefficients: q.coefficients || p.coefficients, leftBinomial: q.leftBinomial || p.leftBinomial, rightBinomial: q.rightBinomial || p.rightBinomial, dividend: q.dividend || p.dividend, divisor: q.divisor || p.divisor, roots: q.roots || p.roots, denominatorRoots: q.denominatorRoots || p.denominatorRoots });
      break;
    }
    case 'signSolutionAnalyzer': {
      const s = q.signChart || q.inequalityModel || {};
      out = copyCommon(q, { type, mode: q.mode || s.mode || 'polynomial', factors: q.factors || s.factors, denominatorFactors: q.denominatorFactors || s.denominatorFactors, relation: q.relation || s.relation, candidates: q.candidates || s.candidates, radicalEquation: q.radicalEquation || s.radicalEquation });
      break;
    }
    case 'sequenceExplorer': {
      let mode = q.mode;
      if (!mode) mode = actions.includes('findMissingTerm') ? 'missingTerm' : actions.includes('partialSum') ? 'partialSum' : actions.includes('compareSequences') ? 'compare' : actions.includes('writeRecursive') || actions.includes('writeExplicit') ? 'ruleBridge' : 'analyze';
      out = copyCommon(q, { type, mode, sequence: q.sequence, targetN: q.targetN, displayCount: q.displayCount, missingIndex: q.missingIndex, sumN: q.sumN, left: q.left, right: q.right, compareN: q.compareN, leftLabel: q.leftLabel, rightLabel: q.rightLabel });
      break;
    }
    case 'complexPlaneLab': {
      const c = q.complex || {};
      out = copyCommon(q, { type, mode: q.mode || c.mode || (actions.includes('complexOperations') ? 'operations' : 'features'), z: q.z || c.z, w: q.w || c.w, operation: q.operation || c.operation, exponent: q.exponent ?? c.exponent, quarterTurns: q.quarterTurns ?? c.quarterTurns, quadratic: q.quadratic || c.quadratic });
      break;
    }
    case 'exponentialLogBridge': {
      const e = q.exponentialLog || q.logarithm || {};
      out = copyCommon(q, { type, mode: q.mode || e.mode || (actions.includes('solveLogarithmic') ? 'solveLogarithmic' : actions.includes('solveExponential') ? 'solveExponential' : 'equivalentForms'), base: q.base ?? e.base, exponent: q.exponent ?? e.exponent, equation: q.equation || e.equation, function: q.function ? toolFunctionSpec(q.function) : e.function, x: q.x ?? e.x, y: q.y ?? e.y });
      break;
    }
    case 'transformationsLab': {
      const t = q.transformation || {};
      out = copyCommon(q, { type, mode: q.mode || t.mode || 'identify', family: q.family || t.family || q.function?.family || q.function?.type, function: q.function ? toolFunctionSpec(q.function) : t.function, target: q.target || t.target, parentPoint: q.parentPoint || t.parentPoint });
      break;
    }
    case 'representationMatch': {
      const r = q.representations || {};
      out = copyCommon(q, { type, mode: q.mode || r.mode || (actions.includes('findRepresentationMismatch') ? 'findMismatch' : 'completeSet'), targetId: q.targetId || r.targetId, sets: q.sets || r.sets, mixedSet: q.mixedSet || r.mixedSet, function: q.function ? toolFunctionSpec(q.function) : r.function, rows: q.rows || r.rows });
      break;
    }
    case 'graphing2': {
      const l = q.lineIntent || q.line || {};
      let mode = q.mode || l.mode;
      if (!mode) mode = q.givenPoints || l.givenPoints ? 'throughPoints' : q.point || l.point ? 'pointSlope' : q.standardForm || l.standard ? 'standardForm' : q.orientation || l.orientation ? 'verticalHorizontal' : 'slopeIntercept';
      out = copyCommon(q, { type, mode, line: q.line || (mode === 'slopeIntercept' ? { m: q.m ?? l.m, b: q.b ?? l.b } : undefined), givenPoints: q.givenPoints || l.givenPoints, point: q.point || l.point, slope: q.slope ?? l.slope, standard: q.standardForm || l.standard, orientation: q.orientation || l.orientation, value: q.value ?? l.value });
      break;
    }
    case 'stepAlgebra2':
      out = copyCommon(q, { type, equation: q.equationModel || q.equation, mode: q.mode, workspaceDifficulty: q.workspaceDifficulty });
      break;
    default:
      throw new Error(`V5 question ${index + 1} selected unsupported destination ${type}.`);
  }
  Object.keys(out).forEach((key) => out[key] === undefined && delete out[key]);
  repairs.push(`compiled V5 question ${index + 1} intent → ${out.type}`);
  return out;
};

export const compileAuthoringIntentV5 = (input = {}) => {
  if (!isObject(input)) throw new Error('Authoring Intent V5 must be a JSON object.');
  if (Number(input.schemaVersion) !== 5) return { package: input, repairs: [], decisions: [] };
  const repairs = [];
  const decisions = [];
  const assignment = { ...(input.assignment || {}) };
  const compileQuestions = (questions = [], role = null) => asArray(questions).map((question, index) => {
    const source = role && isObject(question) && !question.activityRole ? { ...question, activityRole: role } : question;
    const compiled = compileOne(source, index, repairs);
    decisions.push({ index, type: compiled.type, actions: normalizeActions(source) });
    return compiled;
  });
  let packageOut;
  if (Array.isArray(input.activities)) {
    const activities = input.activities.map((activity, activityIndex) => ({
      ...activity,
      role: activity?.role || 'classwork',
      questions: compileQuestions(activity?.questions || [], activity?.role || 'classwork')
    }));
    packageOut = { ...input, schemaVersion: 4, assignment, activities };
  } else {
    packageOut = { ...input, schemaVersion: 4, assignment, questions: compileQuestions(input.questions || []) };
  }
  delete packageOut.authoringIntent;
  repairs.unshift('compiled Authoring Intent V5 into canonical MathMaster V4 runtime questions');
  return { package: packageOut, repairs, decisions };
};

export const AUTHORING_INTENT_V5_ACTIONS = Object.freeze([
  'solveEquation','solveStepByStep','fractionAnswer','chooseNumberLine','constructInterval','writeInterval','readGraph','constructGraph',
  'investigateFunction','analyzeDomain','analyzeRange','analyzeIncreasing','analyzeDecreasing','analyzeConstant','analyzePositive','analyzeNegative',
  'findVertex','findXIntercepts','findYIntercept','findMaximum','findMinimum','solveLiteral','solveSystem','graphSystem','solveInequalitySystem','rowReduce',
  'completeTable','stateOrderedPair','multipleResponses','identifyQuantities','writeEquation','classifyContinuity','matchGraphsToStories','compareGraphs',
  'writeGraphStory','interpretPointInContext','buildMapping','plotRelation','classifyFunction','analyzeSequence','findSequenceTerm','findMissingTerm',
  'writeRecursive','writeExplicit','compareSequences','partialSum','connectRepresentations','findRepresentationMismatch','analyzeData','fitDataModel','predictFromModel',
  'findInverse','composeFunctions','analyzeParabolaGeometry','factorPolynomial','dividePolynomial','multiplyPolynomials','solveInequality','complexOperations','analyzeComplex',
  'exponentialLogBridge','solveExponential','solveLogarithmic','analyzeTransformations','constructLine','modelingLab',
]);
