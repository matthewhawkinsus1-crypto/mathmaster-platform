# MathMaster — Equation → Table → Graph dependency fix

Baseline: `mathmaster-platform-main-5-student-ui-audit-fixed`

## Purpose

This is the permanent implementation of the modeling workflow dependency. It replaces the temporary approach that removed the graph stage.

For a composed `relationshipModel` using the `functionModeling` recipe, MathMaster now supports:

`quantities → equation → table → graph → domain → range → continuity`

The graph is built from the student's work, not from a hidden authored answer.

## Runtime behavior

1. The student writes an equation.
2. The table stage receives that exact student equation and asks the student to complete the authored x-values.
3. The table response is stored as a workflow artifact containing the entered cells, numeric ordered pairs, and lineage to the student's equation.
4. The graph stage does not unlock until the table is complete.
5. If the table and the student's equation disagree, the graph stage tells the student to reconcile them. It does not silently switch to the correct answer key.
6. For a continuous model, the graph stage uses the student's table points and student equation, validates the points, then requires the student to draw the curve through them.
7. For a discrete model, the graph stage uses a point-only coordinate plot and does not draw a connecting curve.
8. If upstream work changes, only the dependent graph work resets. The student's table is not erased merely because the equation/table objects were recreated.
9. The graph viewport expands when necessary so student-generated table points cannot become impossible to plot merely because the authored answer happened to fit a smaller window.
10. Exact numeric table entries such as `1/3` are converted to coordinates correctly instead of being dropped as nonnumeric.

## Grading behavior

The authored correct equation still grades the equation stage. The table stage is graded for consistency with the equation the student actually wrote. The graph stage is graded against the student-derived model/table.

This intentionally supports error carry-forward: one incorrect equation is not automatically counted again as a table error and a graph error if the student correctly uses their own equation. The original mathematical error remains recorded at the equation stage.

## Authoring contract

The authoring instructions now explicitly tell AIs to keep a single modeling task together with:

```json
"recipe": {
  "name": "functionModeling",
  "ask": ["quantities", "equation", "table", "graph", "domain", "range", "continuity"]
}
```

Do not split equation/table/graph merely to work around dependency limitations. Do not place hidden fixed table/graph answers into later stages to simulate dependency.

Continuous table → graph with no equation/function lineage is rejected because finitely many points do not uniquely determine a continuous function. Discrete table → point plot remains valid.

## Files changed

- `src/platform/workflow/modelExpression.js` (new)
- `src/platform/workflow/WorkflowRunner.jsx`
- `src/platform/workflow/workflowGrading.js`
- `src/platform/workflow/questionWorkflow.js`
- `src/platform/workflow/questionRecipes.js`
- `src/functionGraphUtils.js`
- `src/interactiveGraphEngine.js`
- `src/InteractiveGraphWorkspace.jsx`
- `src/platform/contract/semanticValidation.js`
- `src/platform/contract/authoringContract.js`
- `src/platform/contract/questionTypeCatalog.js`
- `INTERACTION_COMPOSITION_ARCHITECTURE.md`
- `tests/platform/modelExpression.test.mjs` (new)
- `tests/platform/workflowGrading.test.mjs`
- `tests/platform/questionWorkflow.test.mjs`
- `tests/platform/questionRecipes.test.mjs`
- `tests/platform/semanticValidation.test.mjs`

## Content fixture

Use `00_T1_Introduction_Problem_Solving_Model_GRAPH_DEPENDENCY_FIXED.json` to verify the intended flow. The graph stage is restored and its prompt explicitly says to use the completed table.

## Deployment / migration

No Firestore migration, rules change, index change, or Cloud Function deployment is required for this change. Deploy the updated client application normally.

## Validation completed here

- Restored Introduction JSON: semantic validation = 0 errors, 0 warnings.
- Workflow dependency + semantic tests that do not require installed third-party math packages: 24/24 passed.
- Changed JSX/JS source files passed TypeScript syntax parsing.
- Changed plain JS/test files passed syntax checks where applicable.

The sandbox's local `node_modules/mathjs` installation is incomplete, so tests importing MathJS could not execute here. `mathjs` is already an existing dependency in this project; this change does not add a new package. Run the full project test/build after a normal `npm ci` in the coding environment.

## Do not regress these invariants

- Never build a dependent graph from the hidden correct answer when the workflow says it comes from student work.
- Never unlock the graph from a partially completed table.
- Never erase table work just because an upstream React object was recreated.
- Never clip required student-derived points out of the graph window.
- Never treat a continuous finite table alone as defining a unique continuous function.
- Never force discrete table data into a connected continuous curve.
